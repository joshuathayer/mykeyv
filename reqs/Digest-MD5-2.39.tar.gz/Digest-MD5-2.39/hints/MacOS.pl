# MWCPPC compiler needs to crank down the optimizations

$self->{MWCPPCOptimize} = "-O1";
